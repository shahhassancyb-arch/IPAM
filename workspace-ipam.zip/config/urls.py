from django.contrib import admin
from django.urls import include, path
from ipamcore.phpipam_import_views import phpipam_import
urlpatterns = [path('admin/phpipam-import/', phpipam_import, name='phpipam-import'), path('admin/', admin.site.urls), path('', include('ipamcore.urls'))]
