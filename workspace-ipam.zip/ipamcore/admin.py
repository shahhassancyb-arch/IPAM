from django.contrib import admin
from .models import AuditEvent, City, Prefix, Region, Section, SectionPermission
@admin.register(Prefix)
class PrefixAdmin(admin.ModelAdmin):
    list_display=('prefix','region','section','allocation_status','network_status','is_marked_full','deleted_at')
    list_filter=('ip_version','allocation_status','network_status','is_public','is_marked_full')
    search_fields=('prefix','description','category')
@admin.register(Section)
class SectionAdmin(admin.ModelAdmin): list_display=('name','parent','region','active','sort_order')
admin.site.register((Region,City,SectionPermission,AuditEvent))
