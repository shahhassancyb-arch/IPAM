from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.db import transaction
import ipaddress, uuid
from django.http import HttpResponseBadRequest
from django.shortcuts import redirect, get_object_or_404
from django.utils import timezone
from .audit import record
from .models import Prefix
from .views import active
from .permissions import can_access
from django.core.exceptions import PermissionDenied
@login_required
def bulk_delete(request):
    if request.method!='POST': return HttpResponseBadRequest('POST required')
    ids=request.POST.getlist('prefix_ids')
    with transaction.atomic():
        roots=list(active.filter(pk__in=ids)); to_delete=set()
        for root in roots:
            if not can_access(request.user,root.section,'delete'): raise PermissionDenied
        def walk(p):
            if p.pk in to_delete: return
            to_delete.add(p.pk)
            for ch in active.filter(parent=p):
                if not can_access(request.user,ch.section,'delete'): raise PermissionDenied
                walk(ch)
        for p in roots: walk(p)
        # Permanent delete leaf first. PROTECT references are intentionally allowed to roll back.
        objects={p.pk:p for p in Prefix.objects.filter(pk__in=to_delete)}
        def depth(p):
            d=0; seen=set(); cur=p
            while cur.parent_id and cur.parent_id in objects and cur.pk not in seen:
                seen.add(cur.pk); d+=1; cur=objects[cur.parent_id]
            return d
        for p in sorted(objects.values(),key=depth,reverse=True):
            record(request.user,'prefix.bulk_delete',p,'Permanently deleted prefix'); p.delete()
    messages.success(request,f'Permanently deleted {len(to_delete)} prefixes and descendants.')
    return redirect('prefix-list')

@login_required
def prefix_bulk_rename(request):
    if request.method!='POST': return HttpResponseBadRequest('POST required')
    root=get_object_or_404(active,pk=request.POST.get('prefix_id'))
    new_text=(request.POST.get('new_prefix') or '').strip()
    try: new_network=ipaddress.ip_network(new_text,strict=True)
    except ValueError as exc: return HttpResponseBadRequest(f'Invalid canonical prefix: {exc}')
    old_network=ipaddress.ip_network(root.prefix,strict=True)
    if new_network.version!=old_network.version or new_network.prefixlen!=old_network.prefixlen:
        return HttpResponseBadRequest('New prefix must have the same IP version and mask length.')
    if not can_access(request.user,root.section,'write'): raise PermissionDenied
    descendants=[]
    def walk(parent):
        for child in active.filter(parent=parent):
            if not can_access(request.user,child.section,'write'): raise PermissionDenied
            descendants.append(child); walk(child)
    walk(root)
    items=[root]+descendants
    replacements={}
    for obj in items:
        old=ipaddress.ip_network(obj.prefix,strict=True)
        if not old.subnet_of(old_network): return HttpResponseBadRequest('A descendant is outside the selected network; refusing rename.')
        offset=int(old.network_address)-int(old_network.network_address)
        target=ipaddress.ip_network((int(new_network.network_address)+offset,old.prefixlen))
        replacements[obj.pk]=str(target)
    conflict=Prefix.objects.filter(prefix__in=replacements.values()).exclude(pk__in=replacements)
    if conflict.exists(): return HttpResponseBadRequest('The target prefix or one of its descendants already exists.')
    with transaction.atomic():
        temp=f'__rename__{uuid.uuid4().hex}_'
        for obj in items: Prefix.objects.filter(pk=obj.pk).update(prefix=temp+str(obj.pk))
        for obj in items:
            before=obj.prefix
            target=replacements[obj.pk]
            obj.prefix=target
            Prefix.objects.filter(pk=obj.pk).update(prefix=target,network=str(ipaddress.ip_network(target).network_address),cidr=ipaddress.ip_network(target).prefixlen,ip_version=ipaddress.ip_network(target).version,updated_at=timezone.now())
            record(request.user,'prefix.rename',obj,f'Renamed {before} to {target}',before={'prefix':before},after={'prefix':target})
    messages.success(request,f'Renamed {len(items)} prefix records, preserving descendant offsets.')
    return redirect('prefix-list')
