import ipaddress
from django.conf import settings
from django.core.exceptions import ValidationError
from django.db import models
from django.utils import timezone

class Region(models.Model):
    name=models.CharField(max_length=80, unique=True)
    code=models.SlugField(max_length=40, unique=True)
    sort_order=models.IntegerField(default=0)
    active=models.BooleanField(default=True)
    class Meta: ordering=('sort_order','name')
    def __str__(self): return self.name

class Section(models.Model):
    name=models.CharField(max_length=100)
    parent=models.ForeignKey('self',null=True,blank=True,on_delete=models.PROTECT,related_name='children')
    region=models.ForeignKey(Region,null=True,blank=True,on_delete=models.PROTECT,related_name='sections')
    sort_order=models.IntegerField(default=0)
    active=models.BooleanField(default=True)
    class Meta:
        ordering=('sort_order','name')
        constraints=[models.UniqueConstraint(fields=['parent','region','name'],name='uniq_section_parent_region_name')]
    def __str__(self): return self.name

class City(models.Model):
    name=models.CharField(max_length=100)
    region=models.ForeignKey(Region,null=True,blank=True,on_delete=models.PROTECT,related_name='cities')
    active=models.BooleanField(default=True)
    created_at=models.DateTimeField(auto_now_add=True)
    updated_at=models.DateTimeField(auto_now=True)
    class Meta:
        ordering=('name',)
        constraints=[models.UniqueConstraint(fields=['region','name'],name='uniq_city_region_name')]
    def __str__(self): return self.name

class Prefix(models.Model):
    class Allocation(models.TextChoices): FREE='free','Free'; ASSIGNED='assigned','Assigned'; RESERVED='reserved','Reserved'
    class NetworkStatus(models.TextChoices): UNKNOWN='unknown','Unknown'; UP='up','Up'; DOWN='down','Configured but down'; NOT_FOUND='not_found','Not found'; DETECTED='detected','Detected'
    network=models.GenericIPAddressField(null=True,blank=True, unpack_ipv4=True)
    cidr=models.PositiveSmallIntegerField(null=True,blank=True)
    prefix=models.CharField(max_length=64,unique=True)
    description=models.TextField(blank=True)
    region=models.ForeignKey(Region,null=True,blank=True,on_delete=models.PROTECT,related_name='prefixes')
    section=models.ForeignKey(Section,null=True,blank=True,on_delete=models.PROTECT,related_name='prefixes')
    city=models.ForeignKey(City,null=True,blank=True,on_delete=models.PROTECT,related_name='prefixes')
    category=models.CharField(max_length=80,blank=True)
    allocation_status=models.CharField(max_length=12,choices=Allocation.choices,default=Allocation.FREE)
    is_marked_full=models.BooleanField(default=False)
    network_status=models.CharField(max_length=12,choices=NetworkStatus.choices,default=NetworkStatus.UNKNOWN)
    is_public=models.BooleanField(default=False)
    ip_version=models.PositiveSmallIntegerField(null=True,blank=True)
    parent=models.ForeignKey('self',null=True,blank=True,on_delete=models.PROTECT,related_name='children')
    created_by=models.ForeignKey(settings.AUTH_USER_MODEL,null=True,blank=True,on_delete=models.SET_NULL,related_name='created_prefixes')
    created_at=models.DateTimeField(auto_now_add=True)
    updated_at=models.DateTimeField(auto_now=True)
    deleted_at=models.DateTimeField(null=True,blank=True,db_index=True)
    class Meta:
        ordering=('prefix',)
        indexes=[models.Index(fields=['region','allocation_status']),models.Index(fields=['ip_version','allocation_status']),models.Index(fields=['city'])]
    def clean(self):
        super().clean()
        try: net=ipaddress.ip_network(self.prefix,strict=True)
        except ValueError as e: raise ValidationError({'prefix':f'Enter a canonical IPv4/IPv6 network: {e}'})
        self.ip_version=net.version; self.network=str(net.network_address); self.cidr=net.prefixlen
        if self.parent_id:
            try: parent_net=ipaddress.ip_network(self.parent.prefix,strict=True)
            except (ValueError,AttributeError): raise ValidationError({'parent':'Parent prefix is invalid.'})
            if parent_net.version != net.version or not net.subnet_of(parent_net) or net == parent_net:
                raise ValidationError({'parent':'Child prefix must be a strict subnet of its parent.'})
    def save(self,*args,**kwargs):
        self.full_clean()
        return super().save(*args,**kwargs)
    @property
    def network_object(self): return ipaddress.ip_network(self.prefix,strict=True)
    @property
    def is_active(self): return self.deleted_at is None
    def soft_delete(self): self.deleted_at=timezone.now(); self.save(update_fields=['deleted_at','updated_at'])
    def __str__(self): return self.prefix

class AuditEvent(models.Model):
    actor=models.ForeignKey(settings.AUTH_USER_MODEL,null=True,blank=True,on_delete=models.SET_NULL,related_name='ipam_audit_events')
    action=models.CharField(max_length=80)
    object_type=models.CharField(max_length=80,blank=True)
    object_id=models.CharField(max_length=80,blank=True)
    summary=models.TextField(blank=True)
    before=models.JSONField(default=dict,blank=True)
    after=models.JSONField(default=dict,blank=True)
    created_at=models.DateTimeField(auto_now_add=True)
    class Meta:
        ordering=('-created_at',)
        indexes=[models.Index(fields=['action','created_at'])]
    def __str__(self): return f'{self.action}: {self.summary}'

class SectionPermission(models.Model):
    class Level(models.TextChoices): READ='read','Read'; WRITE='write','Write'; DELETE='delete','Delete'
    user=models.ForeignKey(settings.AUTH_USER_MODEL,on_delete=models.CASCADE,related_name='section_permissions')
    section=models.ForeignKey(Section,on_delete=models.CASCADE,related_name='user_permissions')
    permission=models.CharField(max_length=10,choices=Level.choices)
    active=models.BooleanField(default=True)
    created_at=models.DateTimeField(auto_now_add=True)
    updated_at=models.DateTimeField(auto_now=True)
    class Meta:
        constraints=[models.UniqueConstraint(fields=['user','section'],name='uniq_user_section_permission')]
    def __str__(self): return f'{self.user} / {self.section}: {self.permission}'
