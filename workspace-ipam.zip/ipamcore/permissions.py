from .models import SectionPermission
RANK={'read':1,'write':2,'delete':3}
def permission_for(user,section):
    if user.is_authenticated and (user.is_staff or user.is_superuser): return 'delete'
    current=section
    while current:
        p=SectionPermission.objects.filter(user=user,section=current,active=True).first()
        if p: return p.permission
        current=current.parent
    return None
def can_access(user,section,needed='read'):
    if user.is_authenticated and (user.is_staff or user.is_superuser): return True
    if section is None: return False
    got=permission_for(user,section)
    return bool(got and RANK.get(got,0)>=RANK.get(needed,99))

def visible_section_ids(user, sections):
    if user.is_authenticated and (user.is_staff or user.is_superuser):
        return None
    return [s.pk for s in sections if can_access(user,s,'read')]
