import csv, io, ipaddress, json
from collections import defaultdict
from django.contrib import messages
from django.contrib.auth import login, logout
from django.contrib.auth.decorators import login_required, user_passes_test
from django.contrib.auth.views import LoginView
from django.core.paginator import Paginator
from django.db import transaction
from django.db.models import Q
from django.http import HttpResponse, HttpResponseBadRequest
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone
from .audit import record
from .models import AuditEvent, City, Prefix, Region, Section, SectionPermission
from .permissions import can_access, visible_section_ids
from django.core.exceptions import PermissionDenied

active=Prefix.objects.filter(deleted_at__isnull=True)
def scoped_prefixes(user, queryset=None, level='read'):
    queryset=queryset if queryset is not None else active
    if user.is_staff or user.is_superuser: return queryset
    sections=list(Section.objects.filter(active=True))
    allowed=[section.pk for section in sections if can_access(user,section,level)]
    return queryset.filter(section_id__in=allowed)
def require_prefix_access(user,p,level='read'):
    if not can_access(user,p.section,level): raise PermissionDenied
def audit_snapshot(p):
    return {'prefix':p.prefix,'description':p.description,'allocation_status':p.allocation_status,'network_status':p.network_status,'section_id':p.section_id}
def login_required_page(view): return login_required(view)

class IPAMLoginView(LoginView):
    template_name='registration/login.html'
    def form_valid(self,form):
        response=super().form_valid(form); record(self.request.user,'auth.login',summary='User signed in'); return response

@login_required
def logout_view(request):
    if request.method!='POST': return HttpResponseBadRequest('POST required')
    record(request.user,'auth.logout',summary='User signed out'); logout(request); return redirect('/login/')

@login_required
def dashboard(request):
    pools=list(scoped_prefixes(request.user).filter(ip_version=4,parent__isnull=True,prefix__endswith='/24').select_related('section','region'))
    def kind(p):
        text=' '.join([p.category or '',p.section.name if p.section_id else '']).lower()
        import re
        if re.search(r'\bprivate\b',text): return 'private'
        if re.search(r'\bpublic\b',text): return 'public'
        return 'unknown'
    def merged_ranges(p):
        spans=[]
        if p.is_marked_full: return [(int(p.network_object.network_address),int(p.network_object.broadcast_address))]
        for ch in active.filter(parent=p).filter(Q(allocation_status__in=['assigned','reserved']) | Q(network_status='down')):
            n=ipaddress.ip_network(ch.prefix); spans.append((int(n.network_address),int(n.broadcast_address)))
        spans.sort(); out=[]
        for a,b in spans:
            if out and a<=out[-1][1]+1: out[-1]=(out[-1][0],max(out[-1][1],b))
            else: out.append((a,b))
        return out
    stats={'public_total':0,'public_used':0,'public_free':0,'reserved':0,'private_total':0,'pools':len(pools)}
    near=[]; low=[]
    for p in pools:
        n=p.network_object; ranges=merged_ranges(p); used=sum(b-a+1 for a,b in ranges); total=n.num_addresses
        k=kind(p); p.dashboard_kind=k; p.used_addresses=used; p.utilization=round(used/total*100,1)
        if k=='public':
            stats['public_total']+=1
            if used: stats['public_used']+=1
            else: stats['public_free']+=1
        if k=='private': stats['private_total']+=1
        if p.allocation_status=='reserved' or active.filter(parent=p,allocation_status='reserved').exists(): stats['reserved']+=1
        if used and p.utilization>=90: near.append(p)
        if used and p.utilization<=5: low.append(p)
    stats['free_by_mask']={}
    for mask in range(25,33):
        cnt=0
        for p in pools:
            if p.is_marked_full: continue
            n=p.network_object
            busy=merged_ranges(p)
            for candidate in n.subnets(new_prefix=mask):
                a,b=int(candidate.network_address),int(candidate.broadcast_address)
                if not any(a<=z and b>=x for x,z in busy): cnt+=1
        stats['free_by_mask'][mask]=cnt
    return render(request,'prefixes/dashboard.html',{'stats':stats,'near_full':near[:20],'low_util':low[:20],'pools':pools[:20]})

@login_required
def dashboard_free_prefixes(request):
    try: mask=int(request.GET.get('mask','25'))
    except ValueError: return HttpResponseBadRequest('Invalid mask')
    if not 25<=mask<=32: return HttpResponseBadRequest('Mask must be 25–32')
    kind=request.GET.get('kind','public')
    if kind not in ('public','private'): return HttpResponseBadRequest('Invalid kind')
    pools=scoped_prefixes(request.user).filter(ip_version=4,parent__isnull=True,prefix__endswith='/24').select_related('section')
    results=[]
    for p in pools:
        label=' '.join([p.category or '',p.section.name if p.section_id else '']).lower()
        import re
        if not re.search(r'\b'+kind+r'\b',label) or p.is_marked_full: continue
        n=p.network_object; busy=[]
        for c in active.filter(parent=p):
            if c.allocation_status in ('assigned','reserved') or c.network_status=='down':
                z=ipaddress.ip_network(c.prefix); busy.append((int(z.network_address),int(z.broadcast_address)))
        for child in n.subnets(new_prefix=mask):
            a,b=int(child.network_address),int(child.broadcast_address)
            if not any(a<=z and b>=x for x,z in busy): results.append({'prefix':str(child),'parent':p})
    return render(request,'prefixes/free_prefixes.html',{'rows':results,'kind':kind,'mask':mask})

@login_required
def prefix_list(request):
    qs=scoped_prefixes(request.user).select_related('region','section','city','parent')
    for key,field in [('region','region_id'),('section','section_id'),('status','allocation_status'),('version','ip_version')]:
        if request.GET.get(key): qs=qs.filter(**{field:request.GET[key]})
    if request.GET.get('q'): qs=qs.filter(Q(prefix__icontains=request.GET['q'])|Q(description__icontains=request.GET['q'])|Q(category__icontains=request.GET['q']))
    if request.GET.get('kind') in ('public','private'): qs=qs.filter(is_public=request.GET['kind']=='public')
    page=Paginator(qs.order_by('prefix'),1000).get_page(request.GET.get('page'))
    return render(request,'prefixes/prefix_list.html',{'page':page,'regions':Region.objects.filter(active=True),'sections':Section.objects.filter(active=True)})

@login_required
def prefix_add(request):
    if request.method=='POST':
        try:
            target_section=request.POST.get('section') or None
            if not can_access(request.user,Section.objects.filter(pk=target_section).first(),'write'): raise PermissionDenied
            p=Prefix(prefix=request.POST.get('prefix','').strip(),description=request.POST.get('description',''),category=request.POST.get('category',''),allocation_status=request.POST.get('allocation_status','free'),network_status=request.POST.get('network_status','unknown'),is_public=request.POST.get('is_public')=='on',region_id=request.POST.get('region') or None,section_id=target_section,city_id=request.POST.get('city') or None,created_by=request.user)
            parent=request.POST.get('parent'); p.parent_id=parent or None
            p.save(); record(request.user,'prefix.create',p,'Created prefix',after=audit_snapshot(p)); messages.success(request,'Prefix created.'); return redirect('prefix-list')
        except Exception as e: messages.error(request,str(e))
    return render(request,'prefixes/prefix_form.html',{'title':'Add prefix','regions':Region.objects.filter(active=True),'sections':Section.objects.filter(active=True),'cities':City.objects.filter(active=True),'prefix':None,'parents':active})

@login_required
def prefix_edit(request,prefix_id):
    p=get_object_or_404(scoped_prefixes(request.user),pk=prefix_id)
    require_prefix_access(request.user,p,'write' if request.method=='POST' else 'read')
    if request.method=='POST':
        before=audit_snapshot(p)
        try:
            p.prefix=request.POST.get('prefix',p.prefix).strip(); p.description=request.POST.get('description',''); p.category=request.POST.get('category',''); p.allocation_status=request.POST.get('allocation_status','free'); p.network_status=request.POST.get('network_status','unknown'); p.is_public=request.POST.get('is_public')=='on'; p.region_id=request.POST.get('region') or None; p.section_id=request.POST.get('section') or None; p.city_id=request.POST.get('city') or None; p.parent_id=request.POST.get('parent') or None
            p.save(); record(request.user,'prefix.update',p,'Updated prefix',before=before,after=audit_snapshot(p)); messages.success(request,'Prefix updated.'); return redirect('prefix-list')
        except Exception as e: messages.error(request,str(e))
    return render(request,'prefixes/prefix_form.html',{'title':'Edit prefix','regions':Region.objects.filter(active=True),'sections':Section.objects.filter(active=True),'cities':City.objects.filter(active=True),'prefix':p,'parents':active.exclude(pk=p.pk)})

@login_required
def prefix_description_update(request,prefix_id):
    p=get_object_or_404(scoped_prefixes(request.user),pk=prefix_id)
    require_prefix_access(request.user,p,'write')
    if request.method=='POST':
        before={'description':p.description}; p.description=request.POST.get('description',''); p.save(); record(request.user,'prefix.description',p,'Updated description',before=before,after={'description':p.description})
    return redirect(request.META.get('HTTP_REFERER','prefix-list'))

@login_required
def prefix_delete(request,prefix_id):
    p=get_object_or_404(scoped_prefixes(request.user),pk=prefix_id)
    require_prefix_access(request.user,p,'delete')
    if request.method=='POST': p.soft_delete(); record(request.user,'prefix.soft_delete',p,'Soft-deleted prefix'); messages.success(request,'Prefix soft-deleted.')
    return redirect('prefix-list')

@login_required
def csv_export(request):
    response=HttpResponse(content_type='text/csv'); response['Content-Disposition']='attachment; filename="ipam-prefixes.csv"'; w=csv.writer(response); w.writerow(['prefix','description','region','section','city','category','allocation_status','network_status','is_public'])
    for p in scoped_prefixes(request.user).select_related('region','section','city'): w.writerow([p.prefix,p.description,p.region.name if p.region_id else '',p.section.name if p.section_id else '',p.city.name if p.city_id else '',p.category,p.allocation_status,p.network_status,p.is_public])
    record(request.user,'csv.export',summary='Exported prefix inventory'); return response

@user_passes_test(lambda u:u.is_staff or u.is_superuser)
def csv_import(request):
    errors=[]; preview=[]
    if request.method=='POST' and request.FILES.get('file'):
        try:
            text=request.FILES['file'].read().decode('utf-8-sig'); rows=list(csv.DictReader(io.StringIO(text))); seen=set()
            for i,row in enumerate(rows,2):
                prefix=(row.get('prefix') or '').strip()
                try: ipaddress.ip_network(prefix,strict=True)
                except ValueError as e: errors.append(f'Row {i}: {e}'); continue
                if prefix in seen or Prefix.objects.filter(prefix=prefix).exists(): errors.append(f'Row {i}: duplicate or existing prefix {prefix}'); continue
                seen.add(prefix); preview.append(row)
            if not errors and request.POST.get('apply')=='1':
                with transaction.atomic():
                    for row in preview:
                        Prefix.objects.create(prefix=row['prefix'],description=row.get('description',''),category=row.get('category',''),allocation_status=row.get('allocation_status') or 'free',network_status=row.get('network_status') or 'unknown',is_public=(row.get('is_public','').lower() in ('true','1','yes')),created_by=request.user)
                record(request.user,'csv.import',summary=f'Imported {len(preview)} prefixes'); messages.success(request,f'Imported {len(preview)} prefixes.'); return redirect('prefix-list')
        except Exception as e: errors.append(str(e))
    return render(request,'prefixes/csv_import.html',{'errors':errors,'preview':preview})

@login_required
def reports_view(request):
    qs=scoped_prefixes(request.user).select_related('region','section','city')
    for key in ('region','city','section','allocation_status','ip_version'):
        if request.GET.get(key): qs=qs.filter(**{key+'_id' if key in ('region','city','section') else key:request.GET[key]})
    return render(request,'prefixes/reports.html',{'rows':qs[:1000]})

@user_passes_test(lambda u:u.is_staff or u.is_superuser)
def audit_view(request):
    qs=AuditEvent.objects.select_related('actor')
    if request.GET.get('action'): qs=qs.filter(action=request.GET['action'])
    if request.GET.get('q'): qs=qs.filter(Q(summary__icontains=request.GET['q'])|Q(object_id__icontains=request.GET['q']))
    return render(request,'prefixes/audit.html',{'events':qs[:500]})

@user_passes_test(lambda u:u.is_staff or u.is_superuser)
def regions_view(request):
    if request.method=='POST':
        if request.POST.get('action')=='delete': Region.objects.filter(pk=request.POST.get('id')).update(active=False)
        else: Region.objects.update_or_create(pk=request.POST.get('id') or None,defaults={'name':request.POST['name'],'code':request.POST['code'],'sort_order':int(request.POST.get('sort_order') or 0),'active':True})
        return redirect('regions')
    return render(request,'prefixes/regions.html',{'rows':Region.objects.all()})

@login_required
def section_list(request):
    if request.method=='POST':
        if not (request.user.is_staff or request.user.is_superuser): raise PermissionDenied
        parent_id=request.POST.get('parent') or None; region_id=request.POST.get('region') or None
        if request.POST.get('action')=='toggle':
            item=get_object_or_404(Section,pk=request.POST['id']); item.active=not item.active; item.save(update_fields=['active'])
        else:
            Section.objects.create(name=request.POST['name'],parent_id=parent_id,region_id=region_id,sort_order=int(request.POST.get('sort_order') or 0))
        return redirect('section-list')
    sections=Section.objects.filter(active=True) if not (request.user.is_staff or request.user.is_superuser) else Section.objects.all()
    if not (request.user.is_staff or request.user.is_superuser): sections=[s for s in sections if can_access(request.user,s,'read')]
    return render(request,'prefixes/sections.html',{'rows':sections,'all_sections':Section.objects.filter(active=True),'regions':Region.objects.filter(active=True)})

@user_passes_test(lambda u:u.is_staff or u.is_superuser)
def cities_view(request):
    if request.method=='POST':
        if request.POST.get('action')=='delete': City.objects.filter(pk=request.POST.get('id')).update(active=False)
        else: City.objects.create(name=request.POST['name'],region_id=request.POST.get('region') or None)
        return redirect('cities')
    return render(request,'prefixes/cities.html',{'rows':City.objects.select_related('region'),'regions':Region.objects.filter(active=True)})

@user_passes_test(lambda u:u.is_staff or u.is_superuser)
def section_permissions(request):
    if request.method=='POST':
        SectionPermission.objects.update_or_create(user_id=request.POST['user'],section_id=request.POST['section'],defaults={'permission':request.POST['permission'],'active':True})
        return redirect('section-permissions')
    from django.contrib.auth import get_user_model
    return render(request,'prefixes/permissions.html',{'rows':SectionPermission.objects.select_related('user','section'),'users':get_user_model().objects.all(),'sections':Section.objects.all()})

@user_passes_test(lambda u:u.is_staff or u.is_superuser)
def users_view(request):
    from django.contrib.auth import get_user_model
    User=get_user_model()
    if request.method=='POST':
        username=request.POST['username']; password=request.POST['password']; User.objects.create_user(username=username,password=password,is_staff=request.POST.get('is_staff')=='on'); return redirect('ipam-users')
    return render(request,'prefixes/users.html',{'users':User.objects.all()})
