from django.apps import AppConfig
class IpamcoreConfig(AppConfig):
    default_auto_field='django.db.models.BigAutoField'
    name='ipamcore'
