from django.contrib import messages
from django.contrib.auth.decorators import user_passes_test
from django.db import transaction
from django.shortcuts import redirect, render
from django.utils.text import slugify
from .audit import record
from .models import Prefix
@user_passes_test(lambda u:u.is_staff or u.is_superuser)
def phpipam_import(request):
    errors=[]; preview=[]
    if request.method=='POST' and request.FILES.get('file'):
        try:
            from openpyxl import load_workbook
            wb=load_workbook(request.FILES['file'],read_only=True,data_only=True)
            ws=wb[request.POST.get('sheet') or wb.sheetnames[0]]
            rows=list(ws.iter_rows(values_only=True)); headers=[str(x or '').strip().lower() for x in rows[0]]
            key=next((x for x in ('subnet','prefix','network') if x in headers),None)
            if not key: raise ValueError('No subnet/prefix/network column found in first row.')
            ix=headers.index(key)
            for i,row in enumerate(rows[1:],2):
                if row[ix]: preview.append({'prefix':str(row[ix]).strip(),'description':str(row[headers.index('description')] or '') if 'description' in headers else ''})
            if request.POST.get('apply')=='1':
                import ipaddress
                with transaction.atomic():
                    for row in preview:
                        ipaddress.ip_network(row['prefix'],strict=True)
                        Prefix.objects.create(prefix=row['prefix'],description=row['description'],created_by=request.user)
                record(request.user,'phpipam.import',summary=f'Imported {len(preview)} workbook rows'); messages.success(request,f'Imported {len(preview)} prefixes.'); return redirect('prefix-list')
        except Exception as e: errors.append(str(e))
    return render(request,'prefixes/phpipam_import.html',{'errors':errors,'preview':preview})
