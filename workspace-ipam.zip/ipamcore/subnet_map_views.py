import ipaddress
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.http import HttpResponse, HttpResponseBadRequest
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_POST
from .audit import record
from .models import Prefix, Section
from .views import active
from .permissions import can_access
from django.core.exceptions import PermissionDenied

@login_required
def subnet_map(request,prefix_id):
    parent=get_object_or_404(active,pk=prefix_id)
    if not can_access(request.user,parent.section,'read'): raise PermissionDenied
    if parent.ip_version!=4: return HttpResponseBadRequest('Space Map currently supports IPv4 only.')
    net=ipaddress.ip_network(parent.prefix)
    children=[]
    for p in active.filter(prefix__isnull=False).exclude(pk=parent.pk).select_related('parent').order_by('prefix'):
        try: childnet=ipaddress.ip_network(p.prefix)
        except ValueError: continue
        if childnet.version==4 and childnet.subnet_of(net):
            p.map_state='full' if p.allocation_status in ('assigned','reserved') or p.network_status=='down' else 'free'
            children.append(p)
    free_counts={}
    for mask in range(max(net.prefixlen,24),33):
        free_counts[mask]=0
        if parent.is_marked_full or mask<net.prefixlen: continue
        busy=[]
        for p in children:
            if p.allocation_status in ('assigned','reserved') or p.network_status=='down':
                c=ipaddress.ip_network(p.prefix); busy.append((int(c.network_address),int(c.broadcast_address)))
        for c in net.subnets(new_prefix=mask) if mask>net.prefixlen else [net]:
            a,b=int(c.network_address),int(c.broadcast_address)
            if not any(a<=z and b>=x for x,z in busy): free_counts[mask]+=1
    return render(request,'prefixes/subnet_map.html',{'parent':parent,'children':children,'free_counts':free_counts,'parent_marked_full':parent.is_marked_full})

@login_required
@require_POST
def subnet_action(request,parent_id):
    parent=get_object_or_404(active,pk=parent_id)
    if not can_access(request.user,parent.section,'write'): raise PermissionDenied
    action=request.POST.get('action')
    if action not in ('mark_full','unmark_full'): return HttpResponseBadRequest('Invalid action')
    before={'is_marked_full':parent.is_marked_full}; parent.is_marked_full=(action=='mark_full'); parent.save(update_fields=['is_marked_full','updated_at'])
    record(request.user,'prefix.mark_full' if parent.is_marked_full else 'prefix.mark_free',parent,'Manual pool capacity override',before=before,after={'is_marked_full':parent.is_marked_full})
    if request.headers.get('X-Requested-With')=='XMLHttpRequest': return HttpResponse('OK',content_type='text/plain')
    return redirect('subnet-map',prefix_id=parent.pk)

@login_required
@require_POST
def bulk_move_pools(request):
    ids=request.POST.getlist('prefix_ids'); section_id=request.POST.get('section') or None
    qs=active.filter(pk__in=ids,parent__isnull=True)
    for pool in qs:
        if not can_access(request.user,pool.section,'write'): raise PermissionDenied
    if not can_access(request.user,Section.objects.filter(pk=section_id).first(),'write'): raise PermissionDenied
    changed=0
    for p in qs:
        old=p.section_id; p.section_id=section_id; p.save(update_fields=['section','updated_at']); record(request.user,'prefix.section_move',p,'Bulk section move',before={'section_id':old},after={'section_id':p.section_id}); changed+=1
    messages.success(request,f'Moved {changed} pools.')
    return redirect('ip-segregation')

@login_required
def ip_segregation(request):
    pools=active.filter(ip_version=4,parent__isnull=True,prefix__endswith='/24').select_related('region','section')
    if not (request.user.is_staff or request.user.is_superuser): pools=[p for p in pools if can_access(request.user,p.section,'read')]
    return render(request,'prefixes/ip_segregation.html',{'pools':pools})
