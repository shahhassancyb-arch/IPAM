from .models import AuditEvent
def record(actor,action,obj=None,summary='',before=None,after=None):
    return AuditEvent.objects.create(actor=actor if getattr(actor,'is_authenticated',False) else None,action=action,object_type=obj.__class__.__name__ if obj else '',object_id=str(obj.pk) if obj else '',summary=summary,before=before or {},after=after or {})
