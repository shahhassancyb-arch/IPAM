from django.conf import settings
from django.contrib.auth import logout
from django.shortcuts import redirect
from django.utils import timezone
class SessionIdleTimeoutMiddleware:
    KEY='ipam_last_activity'
    def __init__(self,get_response): self.get_response=get_response
    def __call__(self,request):
        if request.user.is_authenticated:
            now=int(timezone.now().timestamp()); previous=request.session.get(self.KEY)
            if previous and now-int(previous)>settings.SESSION_IDLE_TIMEOUT_SECONDS:
                logout(request); request.session['ipam_session_expired']=True
                response=redirect('/login/?expired=1')
                return response
            request.session[self.KEY]=now
        return self.get_response(request)
