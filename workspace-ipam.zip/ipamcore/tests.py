import ipaddress
from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse
from .models import AuditEvent, Prefix, Region, Section, SectionPermission
from .permissions import can_access

class PrefixModelTests(TestCase):
    def setUp(self):
        self.region=Region.objects.create(name='Test Region',code='test')
        self.section=Section.objects.create(name='Public',region=self.region)
    def test_prefix_derives_network_version_and_cidr(self):
        p=Prefix(prefix='192.0.2.0/24',section=self.section); p.save()
        self.assertEqual((p.network,p.cidr,p.ip_version),('192.0.2.0',24,4))
    def test_noncanonical_prefix_rejected(self):
        p=Prefix(prefix='192.0.2.1/24',section=self.section)
        with self.assertRaises(Exception): p.save()
    def test_child_must_be_strict_subnet(self):
        parent=Prefix.objects.create(prefix='192.0.2.0/24',section=self.section)
        child=Prefix(prefix='198.51.100.0/24',parent=parent,section=self.section)
        with self.assertRaises(Exception): child.save()

class PermissionTests(TestCase):
    def setUp(self):
        User=get_user_model(); self.user=User.objects.create_user('operator',password='testpass123')
        self.root=Section.objects.create(name='Root'); self.child=Section.objects.create(name='Child',parent=self.root)
    def test_nearest_inherited_permission(self):
        SectionPermission.objects.create(user=self.user,section=self.root,permission='write')
        self.assertTrue(can_access(self.user,self.child,'write'))
        SectionPermission.objects.create(user=self.user,section=self.child,permission='read')
        self.assertTrue(can_access(self.user,self.child,'read'))
        self.assertFalse(can_access(self.user,self.child,'write'))

class WorkflowTests(TestCase):
    def setUp(self):
        User=get_user_model(); self.user=User.objects.create_user('admin',password='testpass123',is_staff=True)
        self.client.force_login(self.user)
        self.section=Section.objects.create(name='Public')
        self.pool=Prefix.objects.create(prefix='198.51.100.0/24',section=self.section,category='Public')
        self.child=Prefix.objects.create(prefix='198.51.100.0/25',parent=self.pool,section=self.section,allocation_status='assigned',description='Kept detail')
    def test_manual_full_and_restore_preserves_child(self):
        url=reverse('subnet-action',args=[self.pool.pk])
        self.client.post(url,{'action':'mark_full'},HTTP_X_REQUESTED_WITH='XMLHttpRequest')
        self.pool.refresh_from_db(); self.child.refresh_from_db()
        self.assertTrue(self.pool.is_marked_full)
        self.assertEqual(self.child.description,'Kept detail')
        self.client.post(url,{'action':'unmark_full'},HTTP_X_REQUESTED_WITH='XMLHttpRequest')
        self.pool.refresh_from_db(); self.child.refresh_from_db()
        self.assertFalse(self.pool.is_marked_full)
        self.assertEqual(self.child.allocation_status,'assigned')
    def test_dashboard_and_inventory_render(self):
        response=self.client.get(reverse('dashboard'))
        self.assertEqual(response.status_code,200)
        self.assertEqual(response.context['stats']['public_used'],1)
        self.assertEqual(response.context['stats']['free_by_mask'][25],1)
        self.assertEqual(self.client.get(reverse('prefix-list')).status_code,200)
    def test_free_prefix_drilldown_matches_busy_ranges(self):
        response=self.client.get(reverse('dashboard-free-prefixes'),{'kind':'public','mask':25})
        self.assertEqual(response.status_code,200)
        self.assertEqual([r['prefix'] for r in response.context['rows']],['198.51.100.128/25'])
    def test_manual_full_writes_audit(self):
        self.client.post(reverse('subnet-action',args=[self.pool.pk]),{'action':'mark_full'})
        self.assertTrue(AuditEvent.objects.filter(action='prefix.mark_full').exists())
    def test_bulk_rename_preserves_child_offset(self):
        response=self.client.post(reverse('prefix-bulk-rename'),{'prefix_id':self.pool.pk,'new_prefix':'203.0.113.0/24'})
        self.assertEqual(response.status_code,302)
        self.pool.refresh_from_db(); self.child.refresh_from_db()
        self.assertEqual(self.pool.prefix,'203.0.113.0/24')
        self.assertEqual(self.child.prefix,'203.0.113.0/25')
